(function(d, params, env, apiHost, hosts) {
	// load script
	(function (d, url, fgJS, firstJS) {
		fgJS = d.createElement('script');
		firstJS = d.getElementsByTagName('script')[0];
		fgJS.src = url
		firstJS.parentNode.insertBefore(fgJS, firstJS);
	})(d, '/gameapi/script/73ae54ea-f54f-480b-bf80-7e42dc3b9fe6/4638e320-4444-4514-81c4-d80a8c662371');
})(document, {}, '', '', {
	'dev': 'api.dev', 
	'staging': 'api.staging.gc',
	'staging.aws': 'api.staging.aws',
	'staging.gc': 'api.staging.gc',
	'prod': 'api'
});